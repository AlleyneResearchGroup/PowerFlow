/******************************************************************************
*   © Copyright 2003.  The U.S. Government, as Represented by the Administrator
*     of the National Aeronautics and Space Administration (NASA).
*   © Copyright 2008, 2009, 2010.  The Ohio Aerospace Institute, on behalf of the NPSS(TM)
*     Consortium.  All rights reserved.  Includes content licensed from the 
*     U.S. Government, National Aeronautics and Space Administration under 
*     United States Copyright Registration Numbers  V3503D364 and V3482D344.
*******************************************************************************/

/******************************************************************************
*  NPSSTM software and related documentation is export controlled
*  with an Export Control Classification Number(ECCN) of 9D991, controlled for
*  Anti-Terrorism reasons, under U.S. Export Administration Regulations 15 CFR
*  730-774. It may not be transferred to a country checked under anti-terrorism
*  on the Commerce Country Chart structure or to foreign nationals of those
*  countries in the U.S. or abroad without first obtaining a license from the
*  Bureau of Industry and Security, United States Department of Commerce. 
*  Violations are punishable by fine, imprisonment, or both.
******************************************************************************
                                               *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *
 * NPSS S-function interface for MATLAB Simulink
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


#define S_FUNCTION_NAME  NPSSSfunction
#define S_FUNCTION_LEVEL 2

#include "simstruc.h"


#include <NPSS_iostream>

#include <NCPException.H>
#include <VariableContainer.H>
#include <Assembly.H>
#include <CommandInterface.H>
#include <InteractiveCmdLine.H>
#include <DataManagerInterface.H>
#include <NPSStokenizer.H>
#include <MsgHandler.H>
#include <ClassObject.H>
#include <RefVarR.H>
#include <LocalSessionManager.H>
#include <NPSSSessionManager.H>

#include <antlr/ANTLRException.hpp>

#ifndef HPACC_OLD_STDLIB
#include <exception>
using std::exception;
#endif

#include <stdlib.h>
#include <stdio.h>

#include <NPSS_VCC.H>

#define M_PRINTLINE(x) ssPrintf("%s\n",x);
#define M_PRINT(x) ssPrintf("%s",x);

#include "MatlabOStream.C"
#include "MatlabOStreamCreator.H"

#include "SimulinkInPortMapper.C"
#include "SimulinkOutPortMapper.C"
#include "SimWorkInfo.C"

// define index labels for work pointer vector entries
#define SIMWORKINFO 0

#ifdef _WIN32
#include <Win32Error.h>
// windows.h defines some things we wish it didn't.
#undef CONST
#undef DELETE
#undef VOID
#endif

extern void setupCustomerModel(CommandInterface*);

NCPReal tStep=0.05;

// override the built-in OutFileStream VCC so we can get output to the 
// Matlab work area
MatlabOStreamCreator mlOScreator("MatlabOStream", "OutFileStream");



//------------------------------------------------------------------------
//------------------------------------------------------------------------
static void version()
{
    ssPrintf("NPSS version ");
    ssPrintf(NPSS::version());
    ssPrintf(" - ");
    ssPrintf(__DATE__);
    ssPrintf(" @ ");
    ssPrintf(__TIME__);
#ifdef SHOW_DEBUG
    ssPrintf(" - DEBUG - ");
#endif
#ifdef SHOW_OPTIMIZE
    ssPrintf(" - OPTIMIZED - ");
#endif
#ifndef USE_CORBA
    ssPrintf(" (CORBA disabled) ");
#endif
    ssPrintf("\n");
}

//-------------------------------------------------------------------------
static void copyright()
{
    M_PRINTLINE(NPSS::copyright().data());
}

//------------------------------------------------------------------------
//------------------------------------------------------------------------
static void usage()
{
   M_PRINTLINE("    Usage: npss [-v] [-h] [-log] [-I includeDir] [-D defName=defVal] [-l dlmModule] [-noiclod] [-nodclod] [-nosolver] [filename(s)]");
   M_PRINTLINE("	-v	 displays version");
   M_PRINTLINE("	-log	 creates a log file called npss.log (interactive mode only)");
   M_PRINTLINE("	-I	 adds includeDir to the #include search path");
   M_PRINTLINE("	-D	 defines a preprocessor variable");
   M_PRINTLINE("	-l       specify a module to dynamicaly load");
   M_PRINTLINE("	-noiclod does not invoke ICLOD on startup");
   M_PRINTLINE("	-nodclod does not invoke DCLOD on startup");
   M_PRINTLINE("   -iclodfirst searches ICLOD before DCLOD");
   M_PRINTLINE("   -nosolver  does not use the default solver and transient at start time");
   M_PRINTLINE("	-h       displays this usage guide");
}

//------------------------------------------------------------------------
// parses a "name=value" string into a name and a value and appends them
// to the appropriate vector
//------------------------------------------------------------------------
static void addDefine(NCPString arg, NPSSvector<NCPString>& names,
		      NPSSvector<NCPString>& vals)
{
  NPSStokenizer tok(arg);
  names.append(tok("="));

  NCPString tmp = tok("\0");
  vals.append(tmp.strip(NCPString::leading, '='));
}


//
// read the config file and set up NPSS-Simulink mappings
// NOTE: the config file must be read TWICE because MATLAB won't let us access
// work vectors at the same time we're setting sizes.
//
int processConfigFile(SimStruct* S, const NCPString &fname, SimWorkInfo* swi)
{
   DBG("processConfigFile")
     
   // create a temporary session containing a VC that I can use as a simple
   // config parser (when lsm goes out of scope, session is cleaned up)
   NPSSSessionManager::start();
   LocalSessionManager lsm;             
   NPSSSession* session = lsm.session();
   VariableContainer* vc = new VariableContainer("");
   session->setTopObj(vc);
   
   // these are the variables we're looking for in the config file
   new RefVarR("timeStep", *(new NCPReal()), vc, VCI::DELETE);
   new RefVarS("commandLine", *(new NCPString()), vc, VCI::DELETE);
   new RefVarS1D("derivatives", *(new NCPStringArray1D()), vc, VCI::DELETE);
   new RefVarS1D("states", *(new NCPStringArray1D()), vc, VCI::DELETE);
   new RefVarR1D("initialValues", *(new NCPRealArray1D()), vc, VCI::DELETE);

   try {
      // make sure DM knows how to create SimulinkInPortMappers and SimulinkOutPortMappers
      SimulinkInPortMapper_init();
      SimulinkOutPortMapper_init();
      
      vc->parseFile(fname);
      
      if(swi == 0) { // first time through, during sizing routine
         // find all of the SimulinkInPortMappers
         VCArray1D inPorts;
         vc->getVCList(ClassObject::findTypeID("SimulinkInPortMapper"),
                      inPorts,VCSecurity::getCurrentSecurity(),1);

         // find all of the SimulinkOutPortMappers
         VCArray1D outPorts;
         vc->getVCList(ClassObject::findTypeID("SimulinkOutPortMapper"),
                      outPorts,VCSecurity::getCurrentSecurity(),1);

         // set the number of input ports. 
         if (!ssSetNumInputPorts(S, inPorts.entries())) {
            ssSetErrorStatus(S,"Can't set number of input ports");
            DBG("Can't set number of input ports");
            return -1; 
         }

         // set the number of output ports.
         if (!ssSetNumOutputPorts(S, outPorts.entries())) {
            ssSetErrorStatus(S,"Can't set number of output ports\n");
            DBG("Can't set number of output ports");
            return -1; 
         }

         // set port widths
         int i;
         for(i=0; i<inPorts.entries(); ++i) {
            NCPStringArray1D vars = inPorts[i]->get("vars").sval1d();
   
            ssSetInputPortDirectFeedThrough(S, i, TRUE);
            ssSetInputPortRequiredContiguous(S, i, TRUE);
            ssSetInputPortWidth(S, i, vars.entries());  
          }

         for(i=0; i<outPorts.entries(); ++i) {
            NCPStringArray1D vars = outPorts[i]->get("vars").sval1d();
   
            ssSetOutputPortWidth(S, i, vars.entries());
            ssSetOutputPortComplexSignal(S,i,COMPLEX_NO);   
         }
         
         NCPStringArray1D stateNames = vc->get("states").sval1d();
         NCPStringArray1D derivNames = vc->get("derivatives").sval1d();
         
         int nStates = stateNames.entries();
         if(stateNames.entries() != derivNames.entries()) {
            M_PRINTLINE("ERROR: different numbers of states and derivatives!"); 
            nStates = 0;
         }
         ssSetNumContStates(S, nStates);   /* number of continuous states */
         
         tStep = vc->get("timeStep").rval();
      }
      else {   // if swi is not 0, we are NOT in mdlInitializeSizes so
               // we can use work vectors
         swi->setup(S, vc);
      }
   }
   catch(NCPMessage& msg) { DBG(msg.getFullMessage().data()); M_PRINTLINE(msg.getFullMessage().data()); }
   catch(std::exception& ex) { DBG(ex.what()); M_PRINTLINE(ex.what()); }
   catch(...) { 
#ifdef _WIN32
    CWin32Error er;
    M_PRINTLINE(er.Description());
    DBG(er.Description());
    M_PRINTLINE("caught an unknown exception in processConfigFile()"); 
#else
    M_PRINTLINE("caught an unknown exception in processConfigFile()"); 
#endif
   }
   
   return 0;
}

    
   
//
// initialize the CommandInterface
//
int initCI(SimStruct* S)
{
    DBG("initCI");
    
    SimWorkInfo* swi = (SimWorkInfo*) ssGetPWork(S)[SIMWORKINFO];
      
    swi->openSession();
    NPSSSession* session = NPSSSessionManager::getCurrentSession();
    NCPStringArray1D& includePaths = session->getIncludePath();
    
    NPSSvector<NCPString> inputFiles;
    NPSSvector<NCPString> defineNames;
    NPSSvector<NCPString> defineVals;
    NCPString AssemblyType="";
    NCPString ExecutiveType="";
    NCPString CompiledObjType="";

    //vector to hold library names, which will be loaded after the CommandInterface is constructed
    NPSSvector<NCPString> minusLib;
    int minusL = FALSE;


    //These are enabled by default
    int useDCLOD=TRUE;
    int useICLOD=TRUE;
    int ICLODfirst=FALSE;
    int useCORBA=FALSE;
    int singleStream=FALSE;
    int noSolver=FALSE;
    int noConstants=FALSE;

    size_t i=0;

    // otherwise, MATLAB just exits with no explanation
    DM::onErrorThrowException();
    
    NPSStokenizer tok(swi->getCommandLine());
    
    NCPStringArray1D args;
    NCPString argsS = NPSS::convertEnvVars(swi->getCommandLine());
    NCPString next;
    int start=0;
    
    while(1) {
       next = NPSS::tokArgs(argsS,start);
       if(next.isNull()) break;
       args.append(NPSS::makeSlashesConsistent(next)); 
    }   
        
    try {
      for(i = 0; i < args.entries(); i++) {
          NCPString argStr(args[i]);

          if(argStr == "-v") {
              version();
              copyright();
          }
          else if(argStr(0,2) == "-I") {
              if(i<args.entries()-1 && argStr.length() == 2)
                  includePaths.append(NPSS::makeSlashesConsistent(args[++i]));
              else if(argStr.length() > 2)
                  includePaths.append(NPSS::makeSlashesConsistent(argStr(2,argStr.length()-2)));
              else {
                  usage();
                  return -1;
              }
          }
          else if(argStr(0,2) == "-D") {
              if(i<args.entries()-1 && argStr.length() == 2) {
                  addDefine(args[++i], defineNames, defineVals);
              }
              else if(argStr.length() > 2) {
                  addDefine(argStr(2,argStr.length()-2), defineNames, 
                                                         defineVals);
              }
              else {
                  usage();
                  return -1;
              }
          }
	  else if(argStr == "-h") {
	      usage();
	  }
          else if(argStr == "-noiclod") {
              useICLOD=FALSE;
          }
          else if(argStr == "-nodclod") {
              useDCLOD=FALSE;
          }
          else if(argStr == "-iclodfirst") {
              ICLODfirst=TRUE;
          }
          else if(argStr == "-nosolver"){
              noSolver = TRUE;
          }
          else if(argStr == "-noconstants"){
              noConstants = TRUE;
          }
          //DLM Stuff
          else if(argStr(0,2) == "-l") {
	    minusL = TRUE;
              if(i<args.entries()-1 && argStr.length() == 2)
		minusLib.append(args[++i]);
              else if(argStr.length() > 2)
                  minusLib.append(argStr(2,argStr.length()-2));
              else {
                  usage();
                  return -1;
              }
          }
          else if(argStr(0,2) == "-a") {
              NCPString access;
              if(i<args.entries()-1 && argStr.length() == 2) {
                  access = args[++i];
              }
              else {
                  access = argStr(2, argStr.length()-2);
              }
              int acc = 0;
              if      (access == "PRIV") { }
              else if (access == "RO") { acc = 1; }
              else if (access == "RW") { acc = 2; }
              else {
                  M_PRINT("error: defaultAccess must be one of 'RW','RO','PRIV' "); 
                  M_PRINTLINE(argStr.data());
                  usage();
                  return -1;
              }
              VCInterface::setDefaultAccess(acc);
          }
          else if(argStr(0) == '-') {
              M_PRINT("npss: illegal option ");
              M_PRINTLINE(argStr.data());
              usage();
              return -1;
          }
          else {  // assume it's an input filename
              inputFiles.append(argStr);
          }
      }
        
      // add any #defines from the command line
      for(size_t j=0; j<defineNames.entries(); j++) {
          session->getCmdDefines()[defineNames[j]] = defineVals[j];
          session->getDefines()[defineNames[j]] = defineVals[j];
      }
        
      NPSS::getEnvPath("NPSS_PATH", includePaths);
      NPSS::addDefaultPaths();

      CommandInterface *cmdInterface = 
            new CommandInterface(AssemblyType, ExecutiveType, 
                                          CompiledObjType, noSolver, noConstants, 
                                          singleStream, useDCLOD, useICLOD, 
                                          ICLODfirst);

      VCInterface* top = cmdInterface->getTopObj();

      // ??? these are currently being removed but not deleted, because
      // deleting them gives an unknown exception...
      top->remove("msgStream");
      top->remove("errStream");
      top->remove("warnStream");
      top->remove("cout");
      top->remove("cerr");

      // replace the NPSS standard streams so we don't lose the output
      top->create(NCPString::emptyString, "MatlabOStream", "cout");
      top->create(NCPString::emptyString, "MatlabOStream", "cerr");
      top->create(NCPString::emptyString, "MatlabOStream", "msgStream");
      top->create(NCPString::emptyString, "MatlabOStream", "errStream");
      top->create(NCPString::emptyString, "MatlabOStream", "warnStream");

      setupCustomerModel(cmdInterface);
      
      for( i=0; i<inputFiles.entries(); i++) {
          cmdInterface->parseFile(inputFiles[i]);
      }
      
      
      // make sure the session and top level transexec have the same 
      // timestep for the first point
//      if(cmdInterface->exists("transient.baseTimeStep")) {
//         VariableContainer::userSetTimeStep(cmdInterface->get("transient.timeStep").rval());
//      }
   }
   catch(NCPMessage& msg) { M_PRINTLINE(msg.getFullMessage().data()); }
   catch(std::exception& ex) { M_PRINTLINE(ex.what()); }
   catch(...) { 
#ifdef _WIN32
    CWin32Error er;
    M_PRINTLINE(er.Description());
    ssSetErrorStatus(S,"caught an unknown exception in initCI()"); 
#else
    ssSetErrorStatus(S,"caught an unknown exception in initCI()"); 
#endif
   }
   
   return 0;
}


/**
 *
 *********************************************************************/
NCPString getConfigFileName(SimStruct* S)
{
     DBG("getConfigFileName");
   
     int_T numParams = ssGetSFcnParamsCount(S);
     if(numParams<1) {
        ssSetErrorStatus(S,"not enough parameters");
        return NCPString::emptyString;
     }
     
     // get the first parameter [config file name]
     const mxArray *arr = ssGetSFcnParam(S,0);
     
     mxClassID cID = mxGetClassID(arr);
     if(cID!=mxCHAR_CLASS) {
        ssSetErrorStatus(S,"first parameter is not a string");
        return NCPString::emptyString;
     }
        
     int buflen = mxGetNumberOfElements(arr)+1;
     char *buff = new char[buflen];
     
     if(buff == 0) {
        ssSetErrorStatus(S,"Memory allocation error for configFile string in mdlProcessParameters");
        return NCPString::emptyString;
     }
     
     auto_ptr<char> bf(buff); // for automatic cleanup
     if(mxGetString(arr , buff, buflen) != 0) {
        ssSetErrorStatus(S,"mxGetString error when processing configFile string");
        return NCPString::emptyString;
     }
     
     NCPString ret = buff;
   
     return ret;
}
  
     
//=====================================================================
//
// BEGIN SIMULINK LEVEL 2 S-FUNCTION INTERFACE
//
//=====================================================================

extern "C" {

#define MDL_CHECK_PARAMETERS   /* Change to #undef to remove function */
#if defined(MDL_CHECK_PARAMETERS) && defined(MATLAB_MEX_FILE)
  static void mdlCheckParameters(SimStruct *S)
  {
     DBG("mdlCheckParameters")
     
     if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
        ssSetErrorStatus(S,"parameter count is wrong");
        return; // parameter mismatch reported by Simulink
     }
     
     if (!mxIsChar(ssGetSFcnParam(S,0))) {
         ssSetErrorStatus(S,"parameter 1 should be the name of the Simulink-NPSS config file");
         return;
     }          
  }
#endif // MDL_CHECK_PARAMETERS


  
#define MDL_PROCESS_PARAMETERS   /* Change to #undef to remove function */
#if defined(MDL_PROCESS_PARAMETERS) && defined(MATLAB_MEX_FILE)
  static void mdlProcessParameters(SimStruct *S)
  {
     DBG("mdlProcessParameters")
     // get command line and size info
     processConfigFile(S,getConfigFileName(S),0); 
     DBG("leaving mdlProcessParameters")
  }
#endif // MDL_PROCESS_PARAMETERS



/*=====================================*
 * Configuration and execution methods *
 *=====================================*/

static void mdlInitializeSizes(SimStruct *S)
{
   try {
      ssSetNumSFcnParams(S, 1);  // Number of expected parameters 
      // set tunability using ssSetSFcnParamTunable(S,idx,0) to set non-tunable
      ssSetSFcnParamTunable(S, 0, 0);

      mdlCheckParameters(S);
    
      int_T needsInput   = 1;  // direct feed through

      // Register the number and type of states the S-Function uses 

       ssSetNumDiscStates(S, 0);   /* number of discrete states */

      /*
       * Set the number of sample times. This must be a positive, nonzero
       * integer indicating the number of sample times or it can be
       * PORT_BASED_SAMPLE_TIMES. For multi-rate S-functions, the
       * suggested approach to setting sample times is via the port
       * based sample times method. When you create a multirate
       * S-function, care needs to be taking to verify that when
       * slower tasks are preempted that your S-function correctly
       * manages data as to avoid race conditions. When port based
       * sample times are specified, the block cannot inherit a constant
       * sample time at any port.
       */
      ssSetNumSampleTimes(   S, 1);   /* number of sample times                */

      /*
       * Set size of the work vectors.
       */
      ssSetNumRWork(         S, 0);   /* number of real work vector elements   */
      ssSetNumIWork(         S, 0);   /* number of integer work vector elements*/
      ssSetNumModes(         S, 0);   /* number of mode work vector elements   */
      ssSetNumNonsampledZCs( S, 0);   /* number of nonsampled zero crossings   */
      ssSetNumPWork(S, 1);   /* number of pointer work vector elements*/

      /*
       * All options have the form SS_OPTION_<name> and are documented in
       * matlabroot/simulink/include/simstruc.h. The options should be
       * bitwise or'd together as in
       *   ssSetOptions(S, (SS_OPTION_name1 | SS_OPTION_name2))
       */

      ssSetOptions(S, 0);   /* general options (SS_OPTION_xx)        */

      mdlProcessParameters(S);
   } 
   catch(NCPMessage& msg) { 
      M_PRINTLINE(msg.getFullMessage().data()); 
      DBG(msg.getFullMessage().data()); 
   }
   catch(std::exception& ex) { 
      M_PRINTLINE(ex.what()); 
      DBG(ex.what()); 
   }
   catch(...) { 
#ifdef _WIN32
    CWin32Error er;
    M_PRINTLINE(er.Description());
    DBG(er.Description());
    ssSetErrorStatus(S,"caught an exception in mdlInitializeSizes()"); 
#else
    ssSetErrorStatus(S,"caught an exception in mdlInitializeSizes()"); 
#endif
   }
    
    DBG("leaving mdlInitializeSizes")

} /* end mdlInitializeSizes */


#define MDL_INITIALIZE_CONDITIONS   /* Change to #undef to remove function */
#if defined(MDL_INITIALIZE_CONDITIONS)
  /*    In this function, you should initialize the continuous and discrete
   *    states for your S-function block.  The initial states are placed
   *    in the state vector, ssGetContStates(S) or ssGetDiscStates(S).
   *    You can also perform any other initialization activities that your
   *    S-function may require. Note, this method will be called at the
   *    start of simulation and if it is present in an enabled subsystem
   *    configured to reset states, it will be call when the enabled subsystem
   *    restarts execution to reset the states.
   *
   *    You can use the ssIsFirstInitCond(S) macro to determine if this is
   *    is the first time mdlInitializeConditions is being called.
   */
  static void mdlInitializeConditions(SimStruct *S)
  {
      DBG("mdlInitializeConditions");
      DBG("SimStruct = " << S)
      DBG("ssGetPWork(S)[SIMWORKINFO] = " << ssGetPWork(S)[SIMWORKINFO])
      
      SimWorkInfo *swi = (SimWorkInfo*) ssGetPWork(S)[SIMWORKINFO];
      if(swi==0) {
       DBG("creating a new SimWorkInfo")
       M_PRINTLINE("creating a new SimWorkInfo");
         swi = new SimWorkInfo;
         ssGetPWork(S)[SIMWORKINFO] = (void*)swi;
         
         processConfigFile(S,getConfigFileName(S),swi);
         
         initCI(S);
         
         swi->initStates(S);
      }
      
      // set the time in NPSS
      DBG("setting time to " << ssGetT(S));
      VariableContainer::userSetTime(ssGetT(S));
      
      DBG("leaving mdlInitializeConditions");
  }
#endif /* MDL_INITIALIZE_CONDITIONS */



#define MDL_DERIVATIVES 
#if defined(MDL_DERIVATIVES)
  static void mdlDerivatives(SimStruct *S)
  {
     DBG("mdlDerivatives");
           
     SimWorkInfo* swi = (SimWorkInfo*) ssGetPWork(S)[SIMWORKINFO];
    
     // retrieve the derivatives from the NPSS model
     swi->updateDerivs(S);
  }
#endif /* MDL_DERIVATIVES */


/* Function: mdlOutputs =======================================================
 * Abstract:
 *    In this function, you compute the outputs of your S-function
 *    block. Generally outputs are placed in the output vector(s),
 *    ssGetOutputPortSignal.
 */
static void mdlOutputs(SimStruct *S, int_T tid)
{
     DBG("mdlOutputs");
     
     SimWorkInfo* swi = (SimWorkInfo*) ssGetPWork(S)[SIMWORKINFO];     
     NPSSSession* session = swi->setSession();
     VCInterface* vc = session->topObj();
      
     // set the time in NPSS
     DBG("setting time to " << ssGetT(S));
     VariableContainer::userSetTime(ssGetT(S));
     
     if(vc->exists("transient.stopTime")) {
//       vc->set("transient.stopTime", ssGetT(S)+session->getTimeStep()); 
//       DBG("setting stop time to " <<  ssGetT(S)+session->getTimeStep()); 
        
        DBG("setting timeStep to " << tStep);
        VariableContainer::userSetTimeStep(tStep);
        vc->set("transient.stopTime", ssGetT(S)+tStep);    
     }
     
     // take data from Simulink input ports and stuff it into the model 
     // variables specified in the config file
     swi->updateInPorts(S);
     
     // stuff state values into the model
     swi->updateStates(S);
     
     // run the model
     try {
        vc->execute();
     }
     catch(NCPMessage& msg) {
        M_PRINTLINE(msg.getFullMessage().data());
        DBG(msg.getFullMessage().data());
     }
     catch(...) {
#ifdef _WIN32
        CWin32Error er;
        M_PRINTLINE(er.Description());
        DBG(er.Description());
        ssSetErrorStatus(S,"caught an exception in mdlOuputs()"); 
#else
        ssSetErrorStatus(S,"caught an exception in mdlOuputs()"); 
#endif
     }    
     
     // retrieve the values of the specified variables and stuff them into the
     // SimulinkOutputPorts
     swi->updateOutPorts(S);
} /* end mdlOutputs */


#define MDL_UPDATE  
#if defined(MDL_UPDATE)
  /* Function: mdlUpdate ======================================================
   * Abstract:
   *    This function is called once for every major integration time step.
   *    Discrete states are typically updated here, but this function is useful
   *    for performing any tasks that should only take place once per
   *    integration step.
   */
  static void mdlUpdate(SimStruct *S, int_T tid)
  {
    DBG("mdlUpdate");
  }
#endif /* MDL_UPDATE */




/* Function: mdlInitializeSampleTimes =========================================
 * Abstract:
 *
 *    This function is used to specify the sample time(s) for your S-function.
 *    You must register the same number of sample times as specified in
 *    ssSetNumSampleTimes. If you specify that you have no sample times, then
 *    the S-function is assumed to have one inherited sample time.
 *
 *    The sample times are specified as pairs "[sample_time, offset_time]"
 *    via the following macros:
 *      ssSetSampleTime(S, sampleTimePairIndex, sample_time)
 *      ssSetOffsetTime(S, offsetTimePairIndex, offset_time)
 *    Where sampleTimePairIndex starts at 0.
 *
 *    The valid sample time pairs are (upper case values are macros defined
 *    in simstruc.h):
 *
 *      [CONTINUOUS_SAMPLE_TIME,  0.0                       ]
 *      [CONTINUOUS_SAMPLE_TIME,  FIXED_IN_MINOR_STEP_OFFSET]
 *      [discrete_sample_period,  offset                    ]
 *      [VARIABLE_SAMPLE_TIME  ,  0.0                       ]
 *
 *    Alternatively, you can specify that the sample time is inherited from the
 *    driving block in which case the S-function can have only one sample time
 *    pair:
 *
 *      [INHERITED_SAMPLE_TIME,  0.0                       ]
 *    or
 *      [INHERITED_SAMPLE_TIME,  FIXED_IN_MINOR_STEP_OFFSET]
 *
 *    The following guidelines may help aid in specifying sample times:
 *
 *      o A continuous function that changes during minor integration steps
 *        should register the [CONTINUOUS_SAMPLE_TIME, 0.0] sample time.
 *      o A continuous function that does not change during minor integration
 *        steps should register the
 *              [CONTINUOUS_SAMPLE_TIME, FIXED_IN_MINOR_STEP_OFFSET]
 *        sample time.
 *      o A discrete function that changes at a specified rate should register
 *        the discrete sample time pair
 *              [discrete_sample_period, offset]
 *        where
 *              discrete_sample_period > 0.0 and
 *              0.0 <= offset < discrete_sample_period
 *      o A discrete function that changes at a variable rate should
 *        register the variable step discrete [VARIABLE_SAMPLE_TIME, 0.0]
 *        sample time. The mdlGetTimeOfNextVarHit function is called to get
 *        the time of the next sample hit for the variable step discrete task.
 *        Note, the VARIABLE_SAMPLE_TIME can be used with variable step
 *        solvers only.
 *      o Discrete blocks which can operate in triggered subsystems.  For your 
 *        block to operate correctly in a triggered subsystem or a periodic 
 *        system it must register [INHERITED_SAMPLE_TIME, 0.0]. In a triggered
 *        subsystem after sample times have been propagated throughout the
 *        block diagram, the assigned sample time to the block will be 
 *        [INHERITED_SAMPLE_TIME, INHERITED_SAMPLE_TIME]. Typically discrete
 *        blocks which can be periodic or reside within triggered subsystems
 *        need to register the inherited sample time and the option
 *        SS_OPTION_DISALLOW_CONSTANT_SAMPLE_TIME. Then in mdlSetWorkWidths, they
 *        need to verify that they were assigned a discrete or triggered
 *        sample time. To do this:
 *          mdlSetWorkWidths:
 *            if (ssGetSampleTime(S, 0) == CONTINUOUS_SAMPLE_TIME) {
 *              ssSetErrorStatus(S, "This block cannot be assigned a "
 *                               "continuous sample time");
 *            }
 *
 *    If your function has no intrinsic sample time, then you should indicate
 *    that your sample time is inherited according to the following guidelines:
 *
 *      o A function that changes as its input changes, even during minor
 *        integration steps should register the [INHERITED_SAMPLE_TIME, 0.0]
 *        sample time.
 *      o A function that changes as its input changes, but doesn't change
 *        during minor integration steps (i.e., held during minor steps) should
 *        register the [INHERITED_SAMPLE_TIME, FIXED_IN_MINOR_STEP_OFFSET]
 *        sample time.
 *
 *    To check for a sample hit during execution (in mdlOutputs or mdlUpdate),
 *    you should use the ssIsSampleHit or ssIsContinuousTask macros.
 *    For example, if your first sample time is continuous, then you
 *    used the following code-fragment to check for a sample hit. Note,
 *    you would get incorrect results if you used ssIsSampleHit(S,0,tid).
 *        if (ssIsContinuousTask(S,tid)) {
 *        }
 *    If say, you wanted to determine if the third (discrete) task has a hit,
 *    then you would use the following code-fragment:
 *        if (ssIsSampleHit(S,2,tid) {
 *        }
 *
 */
static void mdlInitializeSampleTimes(SimStruct *S)
{
    DBG("mdlInitializeSampleTimes")
          
    /* Register one pair for each sample time */
//     if(ssGetNumContStates(S) == 0) {
//        ssSetSampleTime(S, 0, VARIABLE_SAMPLE_TIME);
//     }
//     else {
         ssSetSampleTime(S, 0, tStep);
//    }
    ssSetOffsetTime(S, 0, 0.0);
    ssSetModelReferenceSampleTimeDefaultInheritance(S);
} /* end mdlInitializeSampleTimes */



#define MDL_START  /* Change to #undef to remove function */
#if defined(MDL_START)
  static void mdlStart(SimStruct *S)
  {
      DBG("mdlStart")
     // called at start of model execution. init states here if needed.
  }
#endif /*  MDL_START */


#undef MDL_GET_TIME_OF_NEXT_VAR_HIT  /* Change to #undef to remove function */
#if defined(MDL_GET_TIME_OF_NEXT_VAR_HIT) && (defined(MATLAB_MEX_FILE) || \
                                              defined(NRT))
  static void mdlGetTimeOfNextVarHit(SimStruct *S)
  {
      DBG("mdlGetTimeOfNextVarHit")
            
      SimWorkInfo* swi = (SimWorkInfo*) ssGetPWork(S)[SIMWORKINFO];     
      NPSSSession* session = swi->setSession();
            
      time_T timeOfNextHit = ssGetT(S) + session->getTimeStep();
      DBG("next var hit time is " << timeOfNextHit);
      ssSetTNext(S, timeOfNextHit);
  }
#endif /* MDL_GET_TIME_OF_NEXT_VAR_HIT */


#undef MDL_ZERO_CROSSINGS
#if defined(MDL_ZERO_CROSSINGS) && (defined(MATLAB_MEX_FILE) || defined(NRT))
  static void mdlZeroCrossings(SimStruct *S)
  {
      DBG("mdlZeroCrossings")
  }
#endif /* MDL_ZERO_CROSSINGS */



/**
 * This gets called at the end of each run of the model
 ****************************************************************/
static void mdlTerminate(SimStruct *S)
{
    DBG("mdlTerminate")         
     
//    UNUSED_ARG(S); /* unused input argument */
    
   try {
      SimWorkInfo* swi = (SimWorkInfo*) ssGetPWork(S)[SIMWORKINFO];
      delete swi;
      ssGetPWork(S)[SIMWORKINFO] = 0;
   }
   catch(NCPQuitException &) {
   }
   catch(NCPMessage &msg) {
     M_PRINTLINE(msg.getFullMessage().data());
   }
   catch(exception &err) {
     M_PRINTLINE(err.what());
   }
   catch(...) {
     M_PRINTLINE("Unknown exception caught in mdlTerminate...");
   }    
}

/*=============================*
 * Required S-function trailer *
 *=============================*/

#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif

} // end extern "C"

