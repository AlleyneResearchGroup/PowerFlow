/* Include files */

#include "Boeing737Sample_updatedCopy_sfun.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */
int32_T _sfEvent_;
uint32_T _Boeing737Sample_updatedCopyMachineNumber_;
real_T _sfTime_;

/* Function Declarations */

/* Function Definitions */
void Boeing737Sample_updatedCopy_initializer(void)
{
  _sfEvent_ = CALL_EVENT;
}

void Boeing737Sample_updatedCopy_terminator(void)
{
}

/* SFunction Glue Code */
unsigned int sf_Boeing737Sample_updatedCopy_method_dispatcher(SimStruct
  *simstructPtr, unsigned int chartFileNumber, const char* specsCksum, int_T
  method, void *data)
{
  return 0;
}

unsigned int sf_Boeing737Sample_updatedCopy_process_check_sum_call( int nlhs,
  mxArray * plhs[], int nrhs, const mxArray * prhs[] )
{

#ifdef MATLAB_MEX_FILE

  char commandName[20];
  if (nrhs<1 || !mxIsChar(prhs[0]) )
    return 0;

  /* Possible call to get the checksum */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"sf_get_check_sum"))
    return 0;
  plhs[0] = mxCreateDoubleMatrix( 1,4,mxREAL);
  if (nrhs>1 && mxIsChar(prhs[1])) {
    mxGetString(prhs[1], commandName,sizeof(commandName)/sizeof(char));
    commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
    if (!strcmp(commandName,"machine")) {
      ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(1938235604U);
      ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3486923396U);
      ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(2381694907U);
      ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(429611587U);
    } else if (!strcmp(commandName,"exportedFcn")) {
      ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(0U);
      ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(0U);
      ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(0U);
      ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(0U);
    } else if (!strcmp(commandName,"makefile")) {
      ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3764167653U);
      ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3876242321U);
      ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(3286619096U);
      ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(2849177245U);
    } else if (nrhs==3 && !strcmp(commandName,"chart")) {
      unsigned int chartFileNumber;
      chartFileNumber = (unsigned int)mxGetScalar(prhs[2]);
      switch (chartFileNumber) {
       default:
        ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(0.0);
        ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(0.0);
        ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(0.0);
        ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(0.0);
      }
    } else if (!strcmp(commandName,"target")) {
      ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3176360410U);
      ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(1862911626U);
      ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(659157607U);
      ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(1884031890U);
    } else {
      return 0;
    }
  } else {
    ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(1126299388U);
    ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(1998735117U);
    ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(3582774688U);
    ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(1254322731U);
  }

  return 1;

#else

  return 0;

#endif

}

unsigned int sf_Boeing737Sample_updatedCopy_autoinheritance_info( int nlhs,
  mxArray * plhs[], int nrhs, const mxArray * prhs[] )
{

#ifdef MATLAB_MEX_FILE

  char commandName[32];
  if (nrhs<2 || !mxIsChar(prhs[0]) )
    return 0;

  /* Possible call to get the autoinheritance_info */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"get_autoinheritance_info"))
    return 0;

  {
    unsigned int chartFileNumber;
    chartFileNumber = (unsigned int)mxGetScalar(prhs[1]);
    switch (chartFileNumber) {
     default:
      plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
    }
  }

  return 1;

#else

  return 0;

#endif

}

unsigned int sf_Boeing737Sample_updatedCopy_get_eml_resolved_functions_info( int
  nlhs, mxArray * plhs[], int nrhs, const mxArray * prhs[] )
{

#ifdef MATLAB_MEX_FILE

  char commandName[64];
  if (nrhs<2 || !mxIsChar(prhs[0]))
    return 0;

  /* Possible call to get the get_eml_resolved_functions_info */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"get_eml_resolved_functions_info"))
    return 0;

  {
    unsigned int chartFileNumber;
    chartFileNumber = (unsigned int)mxGetScalar(prhs[1]);
    switch (chartFileNumber) {
     default:
      plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
    }
  }

  return 1;

#else

  return 0;

#endif

}

void Boeing737Sample_updatedCopy_debug_initialize(void)
{
  _Boeing737Sample_updatedCopyMachineNumber_ = sf_debug_initialize_machine(
    "Boeing737Sample_updatedCopy","sfun",0,0,0,0,0);
  sf_debug_set_machine_event_thresholds
    (_Boeing737Sample_updatedCopyMachineNumber_,0,0);
  sf_debug_set_machine_data_thresholds
    (_Boeing737Sample_updatedCopyMachineNumber_,0);
}

void Boeing737Sample_updatedCopy_register_exported_symbols(SimStruct* S)
{
}
