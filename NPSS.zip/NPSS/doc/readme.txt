EXPORT CONTROL
--------------
Contents of this disk are Export Controlled NLR 9E991.

OVERVIEW
--------
This model is a generic 2-spool, mixed flow turbofan model.  It is NOT 
representative of any real engine hardware.  Component maps are derived from
NASA E3 information.

This is intended to be used as a Simulink model.  In the "run" directory, there
is a Simulink model file, PD_25820_Simulink.mdl, that has the basic model
definition.

DIRECTORY STRUCTURE
-------------------
bin    - All necessary DLL files including runtime, component, and
         S-Function libraries

check  - Sample input and output files that can be compared for purposes of 
         checking computational equivalency when transferring the model

data   - Engine data text files, including all component maps and data viewer
         definitions

doc    - Model documentation

model  - Model definition files

output - Model output files

run    - Model input files for executing the modelm including S-Function config
         file

src    - Source files needed by the model, including component definitions



USAGE
-----
This model is intended to be run from the Simulink environment.  The NPSS
S-Function takes as input a configuration file that is specified in the
Property dialog for the S-Function.  This is currently setup to be
"Simulink.config."  This file contains information such as NPSS time-step size
as well as the list of I/O parameters.

The S-Function DLL resides in the /bin directory.  As such, this directory must be 
added to the Matlab/Simulink path.

The basic Simulink model is defined in "run/PD_25820_Simulink.mdl."
**NOTE** THE MDL FILE IN THE MODEL DIRECTORY IS AN NPSS MODEL NOT A SIMULINK MODEL ***
This Simulink model contains one input port and one output port.  Currently, it
is setup with the following input and output parameters:

    INPUT
        - Altitude (ft)
        - Mach No.
        - Delta temperature from standard (�F)
        - Burner exit temperature (�F)
        - HP Compressor Interstage bleed flow (lbm/sec)
        - HP Compressor exit bleed flow (lbm/sec)
        - LP spool power extraction (hp)
        - HP spool power extraction (hp)

    OUTPUT
        - Net Thrust (lbf)
        - Fuel flow (lbm/sec)
        - LP spool speed (rpm)
        - HP spool speed (rpm)

The model uses a pre-load function, contained in run\paths.m, that sets up 
certain environment variables that NPSS checks for.  This allows the Simulink
model to be loaded directly rather than from a command-line environment that
already has these variables defined.

**NOTE** IT IS NOT NECESSARY TO HAVE NPSS IN ORDER TO USE THIS MODEL ***

CONTACT INFORMATION
-------------------
John Pavlicek
john.w.pavlicek@liberty.rolls-royce.com
(317) 230-6202
