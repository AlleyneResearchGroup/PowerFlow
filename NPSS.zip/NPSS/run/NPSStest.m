% tic
% sim('Boeing737Sample_NPSS_1eng.slx')
% toc

figure(3)
a=[0,180,1080,1081,1981,1982,2032,2033,2081,5561,5562,12762,12763,16213,16214,17414,17415,17815,17816,17856,17857,18457,18458,19058];
b=[80,80,80,90,90,90,90,75,75,75,60,60,40,40,60,60,60,60,61,61,65,65,65,65];
plot(a/3600,b)
ylabel('Thrust (lbf)')
xlabel('Mission Time (hrs)')

figure(1)
% data=HPspeed.signals.values(1,1,:)/1000;
% plot(HPspeed.time/3600,reshape(data,size(data,3),1))
plot(HPspeed.time/3600,HPspeed.signals.values)
ylabel('HP Speed (RPM)')
xlabel('Mission Time (hrs)')

figure(2)
% data=RIT.signals.values(1,1,:)/1000;
% plot(RIT.time/3600,reshape(data,size(data,3),1))
plot(RIT.time/3600,RIT.signals.values)
ylabel('RIT (degR)')
xlabel('Mission Time (hrs)')

